# Publishing notes

This is a development prototype. The admin login is implemented in browser storage with a known default password, and the write API does not enforce server-side admin authorization. Do not deploy this backend for real customers or accept orders until authentication, authorization, durable storage, and payment/OTP integrations are implemented and reviewed. The original local `.env` was excluded.
